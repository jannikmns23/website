		let name = prompt('Gib deinen Namen ein:', '');
	
		if (name == null) {
			name = 'Error...';
		  }
		else if (name == '') {
			name = 'MR.X';
		}
	
		document.getElementById("nameBesucher").innerHTML = name;
	
	
